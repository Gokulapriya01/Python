from pycoingecko import CoinGeckoAPI
import pandas as pd

cg=CoinGeckoAPI()

ethereum_coin=cg.get_coin_market_chart_by_id(id='ethereum', vs_currency='USD', days=15)
#print(ethereum_coin)

prices=ethereum_coin['prices']
#print(ethereum_coin)

df=pd.DataFrame(prices,columns=['timestamp','prices'])
#print(df)
df['timestamp']=pd.to_datetime(df['timestamp'],unit='ms')
#print(df)

print(df.head())