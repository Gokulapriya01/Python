from pycoingecko import CoinGeckoAPI
import pandas as pd

cg=CoinGeckoAPI()

doge_data=cg.get_coin_market_chart_by_id(id='dogecoin', vs_currency='USD', days=9)
#print(doge_data)

prices=doge_data['prices']
#print(prices)

df=pd.DataFrame(prices,columns=['timestamp','prices'])
#print(df)

df['timestamp']=pd.to_datetime(df['timestamp'],unit='ms')
print(df)

print(df.head())