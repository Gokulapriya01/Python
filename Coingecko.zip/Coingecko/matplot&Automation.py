from pycoingecko import CoinGeckoAPI
import pandas as pd
import matplotlib.pyplot as plt
import time

cg=CoinGeckoAPI()

def fetch_sol_data():
    plt.figure(figsize=(10,5)) #set figure size
    solana_data=cg.get_coin_market_chart_by_id(id='solana',vs_currency='INR', days=10)
    price=solana_data['prices']
    df=pd.DataFrame(price,columns=('timestamp','price'))
    df['timestamp']=pd.to_datetime(df['timestamp'], unit='ms')
    print(df.head())
    #time.sleep(5)
    plt.plot(df['price'],df['timestamp'])
    # Add labels and title
    plt.xlabel(df['price'])
    plt.ylabel(df['timestamp'])
    plt.title("Crypto Price Trend")
    # Rotate x-axis labels for better visibility
    plt.xticks(rotation=45)
    plt.yticks(rotation=20)
    plt.show()


fetch_sol_data()

