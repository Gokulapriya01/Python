
from pycoingecko import CoinGeckoAPI #CoinGecko API provides real-time and historical cryptocurrency data.
import pandas as pd
cg=CoinGeckoAPI() #Creates a client object (cg) that allows us to call functions to fetch cryptocurrency data.
'''''
o	The below function requests cryptocurrency market data from the API.
o	id='bitcoin':
	Specifies which cryptocurrency we want (Bitcoin).
o	vs_currency='usd':
	Specifies which currency we want the price in (US dollars).
o	days=30:
	Fetches the last 30 days of data.

'''
bitcoin_data=cg.get_coin_market_chart_by_id(id='bitcoin',vs_currency='USD',days=30)
'''''
API Response Format (JSON)
The response from the API is in JSON format, which looks like this:
json
 
{
  "prices": [
    [1700000000000, 42000.50],
    [1700003600000, 42150.75],
    [1700007200000, 42300.25],
    ...
  ],
  "market_caps": [...],
  "total_volumes": [...]
}
Understanding the "prices" List
•	The "prices" key contains a list of [timestamp, price] pairs.
•	Each entry:
o	1700000000000 → UNIX timestamp (milliseconds).
o	42000.50 → Bitcoin price at that timestamp.
We only need the "prices" data, so we extract it:
'''

prices=bitcoin_data['prices'] 
df=pd.DataFrame(prices,columns=['timestamp','prices']) #Converts the list of lists into a DataFrame.
'''''
After above step, the data will look like this:
timestamp	price
1700000000000	42000.50
1700003600000	42150.75
1700007200000	42300.25
...	...
'''
df['timestamp']=pd.to_datetime(df['timestamp'], unit='ms') #the timestamps are in UNIX format, which is difficult to read. 
#We convert them to human-readable format using: to_datetime()
print(df.head(3))