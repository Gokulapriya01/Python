import numpy as np
import matplotlib.pyplot as plt

a=np.array([20,23,40,38,50,60,76,85])
print(type(a)) #check the type of the array we get, numpy.ndarray
print(a.dtype) #use the attribute dtype to obtain the data type of the array's elements.
print(a.size) #size is the number of elements in the array
print(a.shape) #shape is a tuple of integers indicating the size of the array in each dimension. 
print(a.ndim) #ndim represents the number of array dimensions

b=np.array([10.5,20.6,13.7,16.7,30.5])
print(b)
print(b[2]) # retrives element of 2nd index
print(b[2:4]) # retrives element from 2nd index to 4th index exluding 4th.

u=np.array([2, 3])
v=np.array([4,2])
z=u+v # array add
print(z)
z1=u*v #array multiply
print(z1)
f=np.dot(u,v) #dot product ->2*3+4*2
print(f)
x=np.array(["sam","paul","pam"]) #zip the values
w=np.array(["Tesla",'Apple',"Google"])
r=zip(x,w)
print(r)

f2=u+1 # adds 1 to each element
print(f2)

print(b.max())
print(b.min())
print(b.mean())


j=np.array([0,np.pi/2,np.pi])
k=np.sin(j)
print(k)

'''''
Line space returns evenly spaced numbers over a specified interval.
 We specify the starting point of the sequence, the ending point of the 
 sequence. The parameter num indicates the number of samples to generate, 
 in this case five
'''
'''''
l=np.linspace(-5,5,num=5)
print(l)


l1=np.linspace(-0,2*np.pi,50)
l2=np.sin(l1)
print(l2)
plt.plot(l1,l2)
plt.show()
plt.bar(l1,l2)
plt.show()
'''''

arr = np.array([1, 2, 3, 4, 5, 6, 7])

print(arr[1:5:2])
print(arr[:4])
print(arr[4:])
print(arr[1:5:])

for x in arr:
  print(x)

#2D array:
a=[[11,12,13],[21,22,23],[31,32,33]]
b=np.array(a)
print(b)

c=np.array([[11,12,13],[21,22,23],[31,32,33]])
print(c)
print(c[1][2]) #23 Element from 1st row, 2nd column
print(c.ndim)
print(c.shape)
print(c.size)
print(c[0,0:2]) #Elements from row of index 0 to 0,1 column.
print(c[0:2,1])

d=np.array([[1,2,3],[4,5,6],[7,8,9]])
s1=c+d
print(s1)

s3=c-d
print(s3)

s4=2*c
print(s4)

s5=np.dot(c,d) #Matrix Multiplication.
print(s5)

s6=c*d
print(s6)

print(d.T) #T->Transpose

res=np.sqrt(d)
print(res)