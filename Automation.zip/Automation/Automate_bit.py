from pycoingecko import CoinGeckoAPI
import pandas as pd
import matplotlib.pyplot as plt
import time
import schedule

cg=CoinGeckoAPI()

def fetch_data():
    bitcoin_data=cg.get_coin_market_chart_by_id(id='bitcoin',vs_currency='USD', days='2')
    prices=bitcoin_data['prices'][-5:]
    df=pd.DataFrame(prices,columns=['timestamp','prices'])
    df['timestamp']=pd.to_datetime(df['timestamp'],unit='ms')
    csv_path='Bitcoin.csv'
    try:
        df.to_csv(csv_path,mode='a',header=not pd.io.common.file_exists(csv_path),index=False)
    except Exception as e:
        print("Handle Error",e)
    schedule.every(2).minutes.do(fetch_data)
    while True:
        schedule.run_pending()
        time.sleep(60)


    plt.plot(df['timestamp'],df['prices'])

    plt.text("bitcoin price")
    plt.xlabel("price")
    plt.ylabel("timestamp")

fetch_data()
