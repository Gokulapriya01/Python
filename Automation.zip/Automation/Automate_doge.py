from pycoingecko import CoinGeckoAPI
import pandas as pd
import matplotlib.pyplot as plt
import time
import schedule

cg= CoinGeckoAPI()

def fetch_data():
    doge_coin=cg.get_coin_market_chart_by_id(id='dogecoin',vs_currency='USD', days='2')
    prices=doge_coin['prices'][-5:]
    df=pd.DataFrame(prices,columns=['timestamp','prices'])
    df['timestamp']=pd.to_datetime(df['timestamp'], unit='ms')
    csv_file="doge_data.csv"
    try:
        df.to_csv(csv_file,mode='a', header=not pd.io.common.file_exists(csv_file), index=False)
    except Exception as e:
        print("Exception occured in writing",e)
    schedule.every(2).minutes.do(fetch_data)
    while True:
        schedule.run_pending()
        time.sleep(60)
    
    plt.plot(df['timestamp'],df['prices'])
    plt.title("Doge_data")
    plt.xlabel("Price")
    plt.ylabel("timestamp")
    plt.xticks(rotation=35)
    plt.xlim(left=3)
    plt.show()
    

fetch_data()
    

    