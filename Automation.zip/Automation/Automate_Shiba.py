from pycoingecko import CoinGeckoAPI
import pandas as pd
import matplotlib.pyplot as plt
import time
from datetime import datetime
import schedule
cg= CoinGeckoAPI()

def fetch_data():
    plt.figure(figsize=(10,5))
    
    bitcoin_data=cg.get_coin_market_chart_by_id(id='bitcoin',vs_currency='USD',days='2')
    #interval='minute': Fetches data at a minute-level resolution.
    prices=bitcoin_data['prices'][-5:] ## Get the last 5 minutes of prices data
    df=pd.DataFrame(prices,columns=['timestamp','prices'])
    df['timestamp']=pd.to_datetime(df['timestamp'],unit='ms')
    print(df.head())
    csv_file='shiba-inu.csv'
    '''''
    df.to_csv(csv_file, mode='a', header=not pd.io.common.file_exists(csv_file), index=False)
df.to_csv() → Saves a Pandas DataFrame (df) as a CSV file.
csv_file → The file where the data will be saved ('shiba-inu.csv').
mode='a' →
'a' (append mode) means new data will be added to the existing file instead of overwriting it.
If you used 'w' (write mode), it would overwrite the entire file.
header=not pd.io.common.file_exists(csv_file)
Checks if the CSV file already exists:
If the file does not exist (False), header=True, so column names are added.
If the file already exists (True), header=False, so column names are not repeated.
index=False →
Prevents Pandas from saving the DataFrame index column (which is an auto-generated number for each row).
This makes the CSV cleaner, storing only timestamp and price.

    '''''
    try:
        df.to_csv(csv_file,mode='a', header=not pd.io.common.file_exists(csv_file), index=False)
    except Exception as e:
        print("Error writing to CSV:",e)
#Schedules the function fetch_and_save_data() to execute every 5 minutes.
    schedule.every(2).minutes.do(fetch_data)
    print("Script is running... Press CTRL+C to stop.")
    '''''
    Runs indefinitely, checking every 1 second for pending tasks.
If 5 minutes have passed, fetch_and_save_data() runs again.
Press CTRL+C to manually stop the script.
    '''''
    while True:
        schedule.run_pending() ## Runs scheduled tasks
        time.sleep(60) # Wait for 1 second before checking again
  
    plt.plot(df['timestamp'], df['prices'])
    plt.xlabel['prices']
    plt.ylabel['timestamp']
    plt.title("Shiba-Inu price range")
    plt.xticks(rotation=35)
    plt.draw() #to redraw the plot

    plt.pause(1)#plt.pause(1) ensures that the plot is updated every second to reflect real-time data.
    plt.ion() #turns on the interactive mode in Matplotlib, which allows the plot to be updated dynamically.
    plt.show()


fetch_data()

