from randomuser import RandomUser
import pandas as pd

r=RandomUser()
list=r.generate_users(10)
print(r)