from bs4 import BeautifulSoup
import requests

url = 'https://en.wikipedia.org/wiki/IBM'
response=requests.get(url)
html_content=response.text
soup=BeautifulSoup(html_content,'html.parser')
print(html_content[:500])
# Find all <a> tags (anchor tags) in the HTML
links = soup.find_all('a')
# Iterate through the list of links and print their text
for link in links:
    print(link.text)


'''''
Explanation
BeautifulSoup is a library in Python used for parsing HTML and XML documents.
html_content is a string containing HTML code (it can be fetched from a webpage or a file).
'html.parser' is the parser used to interpret the HTML structure.'''