import requests

url='http://httpbin.org/get'
payload={'name':'Joseph','ID':123}
r=requests.get(url,params=payload)
print(r.url) #We can print out the URL and see the name and values.
print(r.headers)
print(r.content)
print(r.status_code) #We can print out the status code.
print(r.request.body)
print(r.text) #We can view the response as text:
#print(r.json())
print(r.headers['Connection']) #We can look at the 'Connection'.
#print(r.json()['args'])