from bs4 import BeautifulSoup
import requests

'''''
requests.get(url) sends a request to the specified URL.
The response contains the HTML code of the IBM Wikipedia page.
'''''
url='https://en.wikipedia.org/wiki/American_Express'
response=requests.get(url)
html_content=response.text #response.text → Extracts the raw HTML content as a string.

'''''
BeautifulSoup(html_content, 'html.parser') converts raw HTML into a structured tree.
'html.parser' allows easy navigation and element extraction.
'''

soup=BeautifulSoup(html_content,'html.parser')
print(html_content[:500]) #Prints the first 500 characters of the page’s HTML.

'''''
soup.find_all('a') searches for all <a> (anchor) tags.
These tags represent hyperlinks in the HTML document.
'''
links=soup.find_all('a')
'''''
Loops through each <a> tag.
Prints only the visible text (not the URL).'''

for link in links:
    print(link)

'''''
soup.find_all('p') retrieves all <p> elements from the parsed HTML.
<p> tags contain paragraph text on the webpage.
'''
    
text1=soup.find_all('p')
for p in text1:
    print(p)

header1=soup.find_all('tr') #soup.find_all('tr') retrieves all <tr>table row elements from the parsed HTML.
for t in header1:
    print(t)