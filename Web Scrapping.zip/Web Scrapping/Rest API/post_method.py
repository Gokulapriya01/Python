import requests

url='http://httpbin.org/get'
payload={'name':'Joseph','ID':123}
r=requests.get(url,params=payload)
print(r.url) #We can print out the URL and see the name and values.
print(r.headers)
print(r.content)
print(r.status_code) #We can print out the status code.
print(r.request.body)
print(r.text) #We can view the response as text:
#print(r.json())
print(r.headers['Connection']) #We can look at the 'Connection'.
#print(r.json()['args'])
url1='http://httpbin.org/post'
response=requests.post(url1,data=payload)
print("POST request URL:",response.url )
print("GET request URL:",r.url)
print("POST request body:",response.request.body)
print("GET request body:",r.request.body)
#response.json()['form']

'''''
Ans:
http://httpbin.org/get?name=Joseph&ID=123
{'Server': 'awselb/2.0', 'Date': 'Tue, 04 Mar 2025 17:40:45 GMT', 'Content-Type': 'text/html', 'Content-Length': '162', 'Connection': 'keep-alive'}
b'<html>\r\n<head><title>503 Service Temporarily Unavailable</title></head>\r\n<body>\r\n<center><h1>503 Service Temporarily Unavailable</h1></center>\r\n</body>\r\n</html>\r\n'
503
None
<html>
<head><title>503 Service Temporarily Unavailable</title></head>
<body>
<center><h1>503 Service Temporarily Unavailable</h1></center>
</body>
</html>

keep-alive
POST request URL: http://httpbin.org/post
GET request URL: http://httpbin.org/get?name=Joseph&ID=123
POST request body: name=Joseph&ID=123
GET request body: None

'''