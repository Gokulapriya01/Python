from bs4 import BeautifulSoup
import requests

url='https://en.wikipedia.org/wiki/JPMorgan_Chase'
r=requests.get(url)
html_c=r.text
print(r.status_code)

soup=BeautifulSoup(html_c,'html.parser')

lines=soup.find_all('p')

for line in lines:
    print(line)