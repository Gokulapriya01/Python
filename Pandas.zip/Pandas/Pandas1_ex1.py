import pandas as pd

'''''
.read_csv()	Reads data from a `.CSV` file and creates a DataFrame.	Syntax: dataframe_name = pd.read_csv("filename.csv") Example: df = pd.read_csv("data.csv")
.read_excel()	Reads data from an Excel file and creates a DataFrame.	Syntax:


dataframe_name = pd.read_excel("filename.xlsx")

#Example:
'''

df = pd.read_excel("data.xlsx")

'''''
#.to_csv()	Writes DataFrame to a CSV file.	Syntax:

dataframe_name.to_csv("output.csv", index=False)
     
#Example:
'''
df.to_csv("output.csv", index=False)

'''''    
Access Columns	Accesses a specific column using [] in the DataFrame.	
Syntax:


dataframe_name["column_name"] # Accesses single column
dataframe_name[["column1", "column2"]] # Accesses multiple columns
'''
#Example:


df["age"]
df[["name", "age"]]

'''''
describe()	Generates statistics summary of numeric columns in the DataFrame.	Syntax:

dataframe_name.describe()
     
Example:

'''

df.describe()

'''''    
drop()	Removes specified rows or columns from the DataFrame. axis=1 indicates columns. axis=0 indicates rows.	Syntax:

dataframe_name.drop(["column1", "column2"], axis=1, inplace=True)
dataframe_name.drop(index=[row1, row2], axis=0, inplace=True)
     
Example:
'''

df.drop(["age", "salary"], axis=1, inplace=True) # Will drop columns
df.drop(index=[5, 10], axis=0, inplace=True) # Will drop rows

'''''
dropna()	Removes rows with missing NaN values from the DataFrame. axis=0 indicates rows.	Syntax:

dataframe_name.dropna(axis=0, inplace=True)
     
Example:

'''

df.dropna(axis=0, inplace=True)

'''''
duplicated()	Duplicate or repetitive values or records within a data set.	Syntax:

dataframe_name.duplicated()
     
Example:
'''

duplicate_rows = df[df.duplicated()]

'''''
     
Filter Rows	Creates a new DataFrame with rows that meet specified conditions.	Syntax:

filtered_df = dataframe_name[(Conditional_statements)]
     
Example:

'''

filtered_df = df[(df["age"] > 30) & (df["salary"] < 50000)]

'''''
groupby()	Splits a DataFrame into groups based on specified criteria, enabling subsequent aggregation, transformation, or analysis within each group.	Syntax:

grouped = dataframe_name.groupby(by, axis=0, level=None, as_index=True,
sort=True, group_keys=True, squeeze=False, observed=False, dropna=True)
     
Example:
'''

grouped = df.groupby(["category", "region"]).agg({"sales": "sum"})
    


'''''    
Import pandas	Imports the Pandas library with the alias pd.	Syntax:

     
info()	Provides information about the DataFrame, including data types and memory usage.	Syntax:

dataframe_name.info()
     
Example:
'''

df.info()

'''''
merge()	Merges two DataFrames based on multiple common columns.	Syntax:

merged_df = pd.merge(df1, df2, on=["column1", "column2"])
     
Example:
'''

merged_df = pd.merge(sales, products, on=["product_id", "category_id"])

'''''
print DataFrame	Displays the content of the DataFrame.	Syntax:

print(df) # or just type df
     
Example:
'''


print(df)

'''''
     
replace()	Replaces specific values in a column with new values.	Syntax:

dataframe_name["column_name"].replace(old_value, new_value, inplace=True)
     
Example:
'''

df["status"].replace("In Progress", "Active", inplace=True)
     
