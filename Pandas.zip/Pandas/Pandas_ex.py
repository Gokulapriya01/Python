import pandas as pd


'''''
Data Structures: Pandas offers two primary data structures - DataFrame 
and Series.

A DataFrame is a two-dimensional, size-mutable, and potentially 
heterogeneous tabular data structure with labeled axes (rows and columns).
A Series is a one-dimensional labeled array, essentially a single column 
or row of data.
'''
'''''
file_path='/Users/gokulapriyas/Documents/Python/Pandas/Df_csv.csv'
df=pd.read_csv(file_path)
df.head()
print(df.head()) #returns 1st 5 rows

data = {'Name': ['Alice', 'Bob', 'Charlie', 'David'],
        'Age': [25, 30, 35, 28],
        'City': ['New York', 'San Francisco', 'Los Angeles', 'Chicago']}
df=pd.DataFrame(data)
print(df)
'''''

#loading excel
file_path1='/Users/gokulapriyas/Documents/Python/Pandas/Df_excel.xlsx'
df1=pd.read_excel(file_path1, engine='openpyxl')
print(df1.head())
print(df1.head(3)) #returns only 3 rows
x=df1[['Join Date']]
print(x)
y=df1[['Country','Device']]
print(y)

print(df1.iloc[0:2]) #access unique elements is with the iloc method
print(df1.iloc[1,1])# retrives element from 1sr row , 1st column 
print(df1.iloc[1:4]) #retrives element from 1,2,3 rows of index=1,2,3

#You can use the name of the row index and the column as well. 
# You can access the first row of the column named artist as follows. 
so=df1.loc[1,'Country'] #returns element of 1st row and the column Country.
print(so)
print(df1.loc[2,'Device'])

'''''
Loc can also be used if the index is not an integer. We create a new 
dataframe called df_new. We replace the index 1, 2, 3 and so on with
a, b, c. '''

data = {'Name': ['Alice', 'Bob', 'Charlie', 'David'],
        'Age': [25, 30, 35, 28],
        'City': ['New York', 'San Francisco', 'Los Angeles', 'Chicago']}
df2=pd.DataFrame(data)
print(df2)

df_new=df2
df_new.index=['a','b','c','d']
print(df2.loc['a','City'])
print(df2)

#You can also slice dataframes and assign the values to a new dataframe. 
# Assign the first two rows and the first three columns to the variable z.
z=df1.iloc[0:2,0:3]
print(z)

t=df1.loc[1:3,'Country':'Device']
print(t) #prints elents fron rows 1-3 and columns Country -Device

#Pandas has the method unique to determine the unique elements in a column of a data frame
a2=df1['Country'].unique()
print(a2)

a3=df1['Join Date'].unique()
print(a3)

u=df1['Age']>37 #returns boolean value by checking every column
print(u)

'''''
We can save the new data frame using the method to_csv. The argument is the 
name of the csv file. Make sure you include a .csv extension.
'''
df3=df1[df1['Age']>37]
print(df1)
df3.to_csv('dataframe_ex.csv')

f=df1.loc[0:2, 'Country':'Device']
print(f)

g=df2.loc['a':'d','Age']
print(g)

e=df2.fillna('N/A') #fills N/A in missing cells.
print(e)

print(df2.tail())#prints last 5 rows of table.
print(df1.groupby("Age"))
'''''
#series
ser=[10,20,30,40,50,60]
se1=pd.Series(ser)
print(se1)
print(se1[0:3])
'''