import pandas as pd

filr_path= '/Users/gokulapriyas/Documents/Python/Pandas/Df_excel.xlsx'
df=pd.read_excel(filr_path,engine='openpyxl')
print(df.head())

sh=df[['Age', 'Device']]
print(sh)

d=df['Age'].unique()
print(d)

print(df.iloc[0,3])
print(df.iloc[0:3])
print(df.iloc[0:4, 0:3])

print(df.loc[0,'Country'])
print(df.loc[4,'Country'])
data = {'Name': ['Alice', 'Bob', 'Charlie', 'David'],
        'Age': [25, 30, 35, 28],
        'City': ['New York', 'San Francisco', 'Los Angeles', 'Chicago']}
df3=pd.DataFrame(data)
print(df3)
dff=df3
dff.index=['a','b','c','d']
print(dff)
print(dff.loc['b','Age'])

s=df[['Age']]>30
print(s)
df3.to_csv("ex.csv")